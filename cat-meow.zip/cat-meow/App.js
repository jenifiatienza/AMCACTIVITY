import React from 'react';
import {View, Text, Image, ScrollView, TextInput} from 'react-native';

const App = () => {
  return (
    <ScrollView>
      <Text>My cat</Text>
      <View>
        <Text>Meow meow</Text>
        <Image
          source={{
            uri: 'https://i.pinimg.com/originals/1b/06/63/1b06634e54179a68a419ac5e7dd9f409.png',
          }}
          style={{width: 200, height: 200}}
        />
      </View>
      <TextInput
        style={{
          height: 40,
          borderColor: 'gray',
          borderWidth: 1,
          textAlign:'center'
          
        }}

        

        
        defaultValue="You can type in me"
      />
    </ScrollView>
  );
};

export default App;
